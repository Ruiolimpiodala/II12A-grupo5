﻿namespace WindowsFormsApplication4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txt_Resultado = new System.Windows.Forms.TextBox();
            this.btn_Apagar = new System.Windows.Forms.Button();
            this.btn_Limpar = new System.Windows.Forms.Button();
            this.btna_Divisao = new System.Windows.Forms.Button();
            this.btn_Nove = new System.Windows.Forms.Button();
            this.btn_Oito = new System.Windows.Forms.Button();
            this.btn_Sete = new System.Windows.Forms.Button();
            this.btn_Exp_Negativo = new System.Windows.Forms.Button();
            this.btn_Percentagem = new System.Windows.Forms.Button();
            this.btn_Raiz = new System.Windows.Forms.Button();
            this.btn_Cinco = new System.Windows.Forms.Button();
            this.btn_Seis = new System.Windows.Forms.Button();
            this.btn_Multiplicação = new System.Windows.Forms.Button();
            this.btn_Quatro = new System.Windows.Forms.Button();
            this.btn_Quadrado = new System.Windows.Forms.Button();
            this.btn_Fatorizar = new System.Windows.Forms.Button();
            this.btn_Zero = new System.Windows.Forms.Button();
            this.btn_Soma = new System.Windows.Forms.Button();
            this.btn_Virgula = new System.Windows.Forms.Button();
            this.btn_Igual = new System.Windows.Forms.Button();
            this.btn_Cubo = new System.Windows.Forms.Button();
            this.btn_Um = new System.Windows.Forms.Button();
            this.btn_Dois = new System.Windows.Forms.Button();
            this.btn_Tres = new System.Windows.Forms.Button();
            this.btn_Subtracao = new System.Windows.Forms.Button();
            this.maisoumenos = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_Resultado
            // 
            this.txt_Resultado.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Resultado.ForeColor = System.Drawing.Color.Black;
            this.txt_Resultado.Location = new System.Drawing.Point(11, 38);
            this.txt_Resultado.Margin = new System.Windows.Forms.Padding(2);
            this.txt_Resultado.Multiline = true;
            this.txt_Resultado.Name = "txt_Resultado";
            this.txt_Resultado.Size = new System.Drawing.Size(326, 40);
            this.txt_Resultado.TabIndex = 0;
            this.txt_Resultado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_Resultado_KeyPress);
            // 
            // btn_Apagar
            // 
            this.btn_Apagar.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Apagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Apagar.ForeColor = System.Drawing.Color.Black;
            this.btn_Apagar.Location = new System.Drawing.Point(117, 84);
            this.btn_Apagar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Apagar.Name = "btn_Apagar";
            this.btn_Apagar.Size = new System.Drawing.Size(50, 40);
            this.btn_Apagar.TabIndex = 4;
            this.btn_Apagar.Text = "C";
            this.btn_Apagar.UseVisualStyleBackColor = false;
            this.btn_Apagar.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_Limpar
            // 
            this.btn_Limpar.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Limpar.ForeColor = System.Drawing.Color.Black;
            this.btn_Limpar.Location = new System.Drawing.Point(11, 84);
            this.btn_Limpar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Limpar.Name = "btn_Limpar";
            this.btn_Limpar.Size = new System.Drawing.Size(102, 40);
            this.btn_Limpar.TabIndex = 6;
            this.btn_Limpar.Text = "CE";
            this.btn_Limpar.UseVisualStyleBackColor = false;
            this.btn_Limpar.Click += new System.EventHandler(this.button6_Click);
            // 
            // btna_Divisao
            // 
            this.btna_Divisao.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btna_Divisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btna_Divisao.ForeColor = System.Drawing.Color.Black;
            this.btna_Divisao.Location = new System.Drawing.Point(228, 126);
            this.btna_Divisao.Margin = new System.Windows.Forms.Padding(2);
            this.btna_Divisao.Name = "btna_Divisao";
            this.btna_Divisao.Size = new System.Drawing.Size(52, 40);
            this.btna_Divisao.TabIndex = 10;
            this.btna_Divisao.Text = "/";
            this.btna_Divisao.UseVisualStyleBackColor = false;
            this.btna_Divisao.Click += new System.EventHandler(this.button10_Click);
            // 
            // btn_Nove
            // 
            this.btn_Nove.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Nove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Nove.ForeColor = System.Drawing.Color.Black;
            this.btn_Nove.Location = new System.Drawing.Point(117, 128);
            this.btn_Nove.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Nove.Name = "btn_Nove";
            this.btn_Nove.Size = new System.Drawing.Size(50, 40);
            this.btn_Nove.TabIndex = 11;
            this.btn_Nove.Text = "9";
            this.btn_Nove.UseVisualStyleBackColor = false;
            this.btn_Nove.Click += new System.EventHandler(this.button11_Click);
            // 
            // btn_Oito
            // 
            this.btn_Oito.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Oito.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Oito.ForeColor = System.Drawing.Color.Black;
            this.btn_Oito.Location = new System.Drawing.Point(63, 128);
            this.btn_Oito.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Oito.Name = "btn_Oito";
            this.btn_Oito.Size = new System.Drawing.Size(50, 40);
            this.btn_Oito.TabIndex = 12;
            this.btn_Oito.Text = "8";
            this.btn_Oito.UseVisualStyleBackColor = false;
            this.btn_Oito.Click += new System.EventHandler(this.button12_Click);
            // 
            // btn_Sete
            // 
            this.btn_Sete.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Sete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sete.ForeColor = System.Drawing.Color.Black;
            this.btn_Sete.Location = new System.Drawing.Point(9, 128);
            this.btn_Sete.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Sete.Name = "btn_Sete";
            this.btn_Sete.Size = new System.Drawing.Size(50, 40);
            this.btn_Sete.TabIndex = 13;
            this.btn_Sete.Text = "7";
            this.btn_Sete.UseVisualStyleBackColor = false;
            this.btn_Sete.Click += new System.EventHandler(this.button13_Click);
            // 
            // btn_Exp_Negativo
            // 
            this.btn_Exp_Negativo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Exp_Negativo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exp_Negativo.ForeColor = System.Drawing.Color.Black;
            this.btn_Exp_Negativo.Location = new System.Drawing.Point(285, 168);
            this.btn_Exp_Negativo.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Exp_Negativo.Name = "btn_Exp_Negativo";
            this.btn_Exp_Negativo.Size = new System.Drawing.Size(53, 40);
            this.btn_Exp_Negativo.TabIndex = 14;
            this.btn_Exp_Negativo.Text = "^-1";
            this.btn_Exp_Negativo.UseVisualStyleBackColor = false;
            this.btn_Exp_Negativo.Click += new System.EventHandler(this.button14_Click);
            // 
            // btn_Percentagem
            // 
            this.btn_Percentagem.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Percentagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Percentagem.ForeColor = System.Drawing.Color.Black;
            this.btn_Percentagem.Location = new System.Drawing.Point(285, 82);
            this.btn_Percentagem.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Percentagem.Name = "btn_Percentagem";
            this.btn_Percentagem.Size = new System.Drawing.Size(53, 40);
            this.btn_Percentagem.TabIndex = 16;
            this.btn_Percentagem.Text = "%";
            this.btn_Percentagem.UseVisualStyleBackColor = false;
            this.btn_Percentagem.Click += new System.EventHandler(this.button16_Click);
            // 
            // btn_Raiz
            // 
            this.btn_Raiz.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Raiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Raiz.ForeColor = System.Drawing.Color.Black;
            this.btn_Raiz.Location = new System.Drawing.Point(171, 170);
            this.btn_Raiz.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Raiz.Name = "btn_Raiz";
            this.btn_Raiz.Size = new System.Drawing.Size(108, 38);
            this.btn_Raiz.TabIndex = 17;
            this.btn_Raiz.Text = "√";
            this.btn_Raiz.UseVisualStyleBackColor = false;
            this.btn_Raiz.Click += new System.EventHandler(this.button17_Click);
            // 
            // btn_Cinco
            // 
            this.btn_Cinco.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Cinco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cinco.ForeColor = System.Drawing.Color.Black;
            this.btn_Cinco.Location = new System.Drawing.Point(63, 172);
            this.btn_Cinco.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Cinco.Name = "btn_Cinco";
            this.btn_Cinco.Size = new System.Drawing.Size(50, 37);
            this.btn_Cinco.TabIndex = 20;
            this.btn_Cinco.Text = "5";
            this.btn_Cinco.UseVisualStyleBackColor = false;
            this.btn_Cinco.Click += new System.EventHandler(this.button20_Click);
            // 
            // btn_Seis
            // 
            this.btn_Seis.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Seis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Seis.ForeColor = System.Drawing.Color.Black;
            this.btn_Seis.Location = new System.Drawing.Point(117, 172);
            this.btn_Seis.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Seis.Name = "btn_Seis";
            this.btn_Seis.Size = new System.Drawing.Size(50, 37);
            this.btn_Seis.TabIndex = 21;
            this.btn_Seis.Text = "6";
            this.btn_Seis.UseVisualStyleBackColor = false;
            this.btn_Seis.Click += new System.EventHandler(this.button21_Click);
            // 
            // btn_Multiplicação
            // 
            this.btn_Multiplicação.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Multiplicação.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Multiplicação.ForeColor = System.Drawing.Color.Black;
            this.btn_Multiplicação.Location = new System.Drawing.Point(228, 82);
            this.btn_Multiplicação.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Multiplicação.Name = "btn_Multiplicação";
            this.btn_Multiplicação.Size = new System.Drawing.Size(53, 40);
            this.btn_Multiplicação.TabIndex = 22;
            this.btn_Multiplicação.Text = "X";
            this.btn_Multiplicação.UseVisualStyleBackColor = false;
            this.btn_Multiplicação.Click += new System.EventHandler(this.button22_Click);
            // 
            // btn_Quatro
            // 
            this.btn_Quatro.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Quatro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Quatro.ForeColor = System.Drawing.Color.Black;
            this.btn_Quatro.Location = new System.Drawing.Point(11, 172);
            this.btn_Quatro.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Quatro.Name = "btn_Quatro";
            this.btn_Quatro.Size = new System.Drawing.Size(50, 37);
            this.btn_Quatro.TabIndex = 23;
            this.btn_Quatro.Text = "4";
            this.btn_Quatro.UseVisualStyleBackColor = false;
            this.btn_Quatro.Click += new System.EventHandler(this.button23_Click);
            // 
            // btn_Quadrado
            // 
            this.btn_Quadrado.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Quadrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Quadrado.ForeColor = System.Drawing.Color.Black;
            this.btn_Quadrado.Location = new System.Drawing.Point(228, 212);
            this.btn_Quadrado.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Quadrado.Name = "btn_Quadrado";
            this.btn_Quadrado.Size = new System.Drawing.Size(53, 40);
            this.btn_Quadrado.TabIndex = 24;
            this.btn_Quadrado.Text = "^2";
            this.btn_Quadrado.UseVisualStyleBackColor = false;
            this.btn_Quadrado.Click += new System.EventHandler(this.button24_Click);
            // 
            // btn_Fatorizar
            // 
            this.btn_Fatorizar.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Fatorizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Fatorizar.ForeColor = System.Drawing.Color.Black;
            this.btn_Fatorizar.Location = new System.Drawing.Point(171, 212);
            this.btn_Fatorizar.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Fatorizar.Name = "btn_Fatorizar";
            this.btn_Fatorizar.Size = new System.Drawing.Size(53, 40);
            this.btn_Fatorizar.TabIndex = 42;
            this.btn_Fatorizar.Text = "10x";
            this.btn_Fatorizar.UseVisualStyleBackColor = false;
            this.btn_Fatorizar.Click += new System.EventHandler(this.button29_Click);
            // 
            // btn_Zero
            // 
            this.btn_Zero.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Zero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Zero.ForeColor = System.Drawing.Color.Black;
            this.btn_Zero.Location = new System.Drawing.Point(11, 256);
            this.btn_Zero.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Zero.Name = "btn_Zero";
            this.btn_Zero.Size = new System.Drawing.Size(156, 53);
            this.btn_Zero.TabIndex = 41;
            this.btn_Zero.Text = "0";
            this.btn_Zero.UseVisualStyleBackColor = false;
            this.btn_Zero.Click += new System.EventHandler(this.button30_Click);
            // 
            // btn_Soma
            // 
            this.btn_Soma.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Soma.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Soma.ForeColor = System.Drawing.Color.Black;
            this.btn_Soma.Location = new System.Drawing.Point(171, 126);
            this.btn_Soma.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Soma.Name = "btn_Soma";
            this.btn_Soma.Size = new System.Drawing.Size(53, 40);
            this.btn_Soma.TabIndex = 39;
            this.btn_Soma.Text = "+";
            this.btn_Soma.UseVisualStyleBackColor = false;
            this.btn_Soma.Click += new System.EventHandler(this.button32_Click);
            // 
            // btn_Virgula
            // 
            this.btn_Virgula.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Virgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Virgula.ForeColor = System.Drawing.Color.Black;
            this.btn_Virgula.Location = new System.Drawing.Point(171, 256);
            this.btn_Virgula.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Virgula.Name = "btn_Virgula";
            this.btn_Virgula.Size = new System.Drawing.Size(50, 53);
            this.btn_Virgula.TabIndex = 38;
            this.btn_Virgula.Text = ",";
            this.btn_Virgula.UseVisualStyleBackColor = false;
            this.btn_Virgula.Click += new System.EventHandler(this.button33_Click);
            // 
            // btn_Igual
            // 
            this.btn_Igual.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Igual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_Igual.ForeColor = System.Drawing.Color.Black;
            this.btn_Igual.Location = new System.Drawing.Point(285, 212);
            this.btn_Igual.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Igual.Name = "btn_Igual";
            this.btn_Igual.Size = new System.Drawing.Size(53, 97);
            this.btn_Igual.TabIndex = 35;
            this.btn_Igual.Text = "=";
            this.btn_Igual.UseVisualStyleBackColor = false;
            this.btn_Igual.Click += new System.EventHandler(this.button36_Click);
            // 
            // btn_Cubo
            // 
            this.btn_Cubo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Cubo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cubo.ForeColor = System.Drawing.Color.Black;
            this.btn_Cubo.Location = new System.Drawing.Point(284, 126);
            this.btn_Cubo.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Cubo.Name = "btn_Cubo";
            this.btn_Cubo.Size = new System.Drawing.Size(53, 37);
            this.btn_Cubo.TabIndex = 32;
            this.btn_Cubo.Text = "^3";
            this.btn_Cubo.UseVisualStyleBackColor = false;
            this.btn_Cubo.Click += new System.EventHandler(this.button39_Click);
            // 
            // btn_Um
            // 
            this.btn_Um.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Um.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Um.ForeColor = System.Drawing.Color.Black;
            this.btn_Um.Location = new System.Drawing.Point(9, 213);
            this.btn_Um.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Um.Name = "btn_Um";
            this.btn_Um.Size = new System.Drawing.Size(50, 40);
            this.btn_Um.TabIndex = 31;
            this.btn_Um.Text = "1";
            this.btn_Um.UseVisualStyleBackColor = false;
            this.btn_Um.Click += new System.EventHandler(this.button40_Click);
            // 
            // btn_Dois
            // 
            this.btn_Dois.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Dois.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dois.ForeColor = System.Drawing.Color.Black;
            this.btn_Dois.Location = new System.Drawing.Point(63, 212);
            this.btn_Dois.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Dois.Name = "btn_Dois";
            this.btn_Dois.Size = new System.Drawing.Size(50, 40);
            this.btn_Dois.TabIndex = 30;
            this.btn_Dois.Text = "2";
            this.btn_Dois.UseVisualStyleBackColor = false;
            this.btn_Dois.Click += new System.EventHandler(this.button41_Click);
            // 
            // btn_Tres
            // 
            this.btn_Tres.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Tres.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Tres.ForeColor = System.Drawing.Color.Black;
            this.btn_Tres.Location = new System.Drawing.Point(117, 212);
            this.btn_Tres.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Tres.Name = "btn_Tres";
            this.btn_Tres.Size = new System.Drawing.Size(50, 40);
            this.btn_Tres.TabIndex = 29;
            this.btn_Tres.Text = "3";
            this.btn_Tres.UseVisualStyleBackColor = false;
            this.btn_Tres.Click += new System.EventHandler(this.button42_Click);
            // 
            // btn_Subtracao
            // 
            this.btn_Subtracao.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Subtracao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Subtracao.ForeColor = System.Drawing.Color.Black;
            this.btn_Subtracao.Location = new System.Drawing.Point(171, 82);
            this.btn_Subtracao.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Subtracao.Name = "btn_Subtracao";
            this.btn_Subtracao.Size = new System.Drawing.Size(53, 40);
            this.btn_Subtracao.TabIndex = 28;
            this.btn_Subtracao.Text = "-";
            this.btn_Subtracao.UseVisualStyleBackColor = false;
            this.btn_Subtracao.Click += new System.EventHandler(this.button43_Click);
            // 
            // maisoumenos
            // 
            this.maisoumenos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.maisoumenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maisoumenos.ForeColor = System.Drawing.Color.Black;
            this.maisoumenos.Location = new System.Drawing.Point(228, 256);
            this.maisoumenos.Margin = new System.Windows.Forms.Padding(2);
            this.maisoumenos.Name = "maisoumenos";
            this.maisoumenos.Size = new System.Drawing.Size(54, 53);
            this.maisoumenos.TabIndex = 44;
            this.maisoumenos.Text = "+/-";
            this.maisoumenos.UseVisualStyleBackColor = false;
            this.maisoumenos.Click += new System.EventHandler(this.maisoumenos_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 45;
            this.label1.Text = "calcular:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(347, 320);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.maisoumenos);
            this.Controls.Add(this.btn_Fatorizar);
            this.Controls.Add(this.btn_Soma);
            this.Controls.Add(this.btn_Virgula);
            this.Controls.Add(this.btn_Igual);
            this.Controls.Add(this.btn_Cubo);
            this.Controls.Add(this.btn_Um);
            this.Controls.Add(this.btn_Dois);
            this.Controls.Add(this.btn_Tres);
            this.Controls.Add(this.btn_Subtracao);
            this.Controls.Add(this.btn_Quadrado);
            this.Controls.Add(this.btn_Quatro);
            this.Controls.Add(this.btn_Multiplicação);
            this.Controls.Add(this.btn_Seis);
            this.Controls.Add(this.btn_Cinco);
            this.Controls.Add(this.btn_Raiz);
            this.Controls.Add(this.btn_Percentagem);
            this.Controls.Add(this.btn_Exp_Negativo);
            this.Controls.Add(this.btn_Sete);
            this.Controls.Add(this.btn_Oito);
            this.Controls.Add(this.btn_Nove);
            this.Controls.Add(this.btna_Divisao);
            this.Controls.Add(this.btn_Limpar);
            this.Controls.Add(this.btn_Apagar);
            this.Controls.Add(this.txt_Resultado);
            this.Controls.Add(this.btn_Zero);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculado Cientifica";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Resultado;
        private System.Windows.Forms.Button btn_Apagar;
        private System.Windows.Forms.Button btn_Limpar;
        private System.Windows.Forms.Button btna_Divisao;
        private System.Windows.Forms.Button btn_Nove;
        private System.Windows.Forms.Button btn_Oito;
        private System.Windows.Forms.Button btn_Sete;
        private System.Windows.Forms.Button btn_Exp_Negativo;
        private System.Windows.Forms.Button btn_Percentagem;
        private System.Windows.Forms.Button btn_Raiz;
        private System.Windows.Forms.Button btn_Cinco;
        private System.Windows.Forms.Button btn_Seis;
        private System.Windows.Forms.Button btn_Multiplicação;
        private System.Windows.Forms.Button btn_Quatro;
        private System.Windows.Forms.Button btn_Quadrado;
        private System.Windows.Forms.Button btn_Fatorizar;
        private System.Windows.Forms.Button btn_Zero;
        private System.Windows.Forms.Button btn_Soma;
        private System.Windows.Forms.Button btn_Virgula;
        private System.Windows.Forms.Button btn_Igual;
        private System.Windows.Forms.Button btn_Cubo;
        private System.Windows.Forms.Button btn_Um;
        private System.Windows.Forms.Button btn_Dois;
        private System.Windows.Forms.Button btn_Tres;
        private System.Windows.Forms.Button btn_Subtracao;
        private System.Windows.Forms.Button maisoumenos;
        private System.Windows.Forms.Label label1;
    }
}

